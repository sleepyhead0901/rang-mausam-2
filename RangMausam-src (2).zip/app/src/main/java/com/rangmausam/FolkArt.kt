package com.rangmausam

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// =====================================================================
// Shared frame helpers
// =====================================================================
fun Ink.paperBg(w: Double, h: Double, bg: String, grain: String, seed: Int = 42) {
    fill("M 0 0 L $w 0 L $w $h L 0 $h Z", bg)
    val R = Ink.Rng(seed); val g = ca(grain, 0.07)
    for (i in 0 until (w * h / 90).toInt()) dot(R.next() * w, R.next() * h, 0.3 + R.next() * 0.9, g)
}

fun Ink.dotFrame(w: Double, h: Double, line: String, dots: String) {
    val i = 7.0; val r = 16.0
    line("M ${i + r} $i L ${w - i - r} $i Q ${w - i} $i ${w - i} ${i + r} L ${w - i} ${h - i - r} Q ${w - i} ${h - i} ${w - i - r} ${h - i} L ${i + r} ${h - i} Q $i ${h - i} $i ${h - i - r} L $i ${i + r} Q $i $i ${i + r} $i Z", line, 1.4)
    val j = 11.5
    for (x in incl(j + 12, w - j - 12, 7.0)) { dot(x, j, 1.1, dots); dot(x, h - j, 1.1, dots) }
    for (y in incl(j + 12, h - j - 12, 7.0)) { dot(j, y, 1.1, dots); dot(w - j, y, 1.1, dots) }
    for (p in listOf(j + 3 to j + 3, w - j - 3 to j + 3, j + 3 to h - j - 3, w - j - 3 to h - j - 3)) flower4(p.first, p.second, 2.4, dots, line)
}

private fun Ink.archPath(x: Double, y: Double, w: Double, h: Double): String {
    val sh = min(h * 0.26, w * 0.34)
    return "M $x ${y + h} L $x ${y + sh} C $x ${y + sh * 0.45} ${x + w * 0.3} ${y + sh * 0.38} ${x + w * 0.42} ${y + sh * 0.12} Q ${x + w * 0.5} $y ${x + w * 0.5} ${y - sh * 0.18} Q ${x + w * 0.5} $y ${x + w * 0.58} ${y + sh * 0.12} C ${x + w * 0.7} ${y + sh * 0.38} ${x + w} ${y + sh * 0.45} ${x + w} ${y + sh} L ${x + w} ${y + h} Z"
}

private fun lang(l: String, m: Map<String, String>) = m[l] ?: m.getValue("hi")
private fun fmtInt(n: Int): String = "%,d".format(n)

// =====================================================================
// RAGA CLOCK
// =====================================================================
fun Ink.ragaWidget(w: Double, h: Double, r: Raga, frac: Double, nowLabel: String) {
    paperBg(w, h, "#F3E3C3", "#7A2A12", 11)
    val wide = w / h >= 1.45
    if (wide) {
        val ps = h - 24
        push(12.0, 12.0); ragaPainting(r, ps * 0.92, ps, frac); pop()
        val x = 12 + ps * 0.92 + 14; val tw = w - x - 16
        text(if (nowLabel.isEmpty()) "RAGA OF THE HOUR" else "RAGA OF THE HOUR · ${nowLabel.uppercase()}", x, 16.0, tw, 12.0, fonts.sansBold, 7.5, "#7A2A12")
        val big = if (r.deva.length > 7) 17.0 else 22.0
        var y = 28.0
        y += text(r.deva, x, y, tw, 30.0, fonts.indic, big, "#A3261C")
        y += text(r.name, x, y - 2, tw, 24.0, fonts.serif, 15.0, "#2A1A14")
        y += text("${r.period}, ${Ragas.window(r)}", x, y, tw, 12.0, fonts.sansBold, 8.5, "#7A4A24") + 2
        text(r.mood, x, y, tw, 14.0, fonts.italic, 10.5, "#2A1A14")
        val extra = listOfNotNull("${r.thaat} thaat", r.carnatic?.let { "Carnatic: $it" }).joinToString("  ·  ")
        text(extra, x, h - 50, tw, 12.0, fonts.sansBold, 7.2, "#7A4A24")
        val nx = Ragas.next(r)
        text("Next: ${nx.name} at ${Ragas.hourLabel(nx.start)}  ·  tap to listen", x, h - 37, tw, 12.0, fonts.sansBold, 7.2, "#7A2A12")
        // the day's twelve slots as a bead string, current one lit
        val by = h - 19.0; val step = min(14.0, (tw - 8) / 11)
        for (i in 0 until 12) {
            val rr = Ragas.ALL.sortedBy { it.start }[i]
            val cx = x + 4 + i * step
            if (rr.start == r.start) { dot(cx, by, 4.2, "#A3261C"); ring(cx, by, 5.6, "#E9B949", 1.2) }
            else dot(cx, by, 2.2, if (rr.start in 6..17) "#E9B949" else "#3B3F7A")
        }
    } else {
        val label = 30.0
        push(10.0, 10.0); ragaPainting(r, w - 20, h - 20 - label, frac); pop()
        text(r.deva, 12.0, h - label - 6, w - 24, 22.0, fonts.indic, if (r.deva.length > 7) 12.0 else 15.0, "#A3261C")
        text(Ragas.window(r), 12.0, h - 18, w - 24, 12.0, fonts.sansBold, 7.5, "#7A4A24", Ink.Align.RIGHT)
        if (r.name.length <= 9) text(r.name, 12.0, h - 18, w - 24, 12.0, fonts.sansBold, 8.0, "#2A1A14")
    }
}

// =====================================================================
// STEPS: a Warli procession, and the Wari route
// =====================================================================
object Wari {
    /** Halts of Sant Dnyaneshwar's palkhi, in order. Spacing between halts is shown evenly; only the total is real. */
    val HALTS = listOf("Alandi", "Pune", "Saswad", "Jejuri", "Valhe", "Lonand", "Taradgaon", "Phaltan", "Barad",
        "Natepute", "Malshiras", "Velapur", "Bhandishegaon", "Wakhari", "Pandharpur")
    const val TOTAL_KM = 250.0
    val TITLE = mapOf("hi" to "क़दम", "kn" to "ಹೆಜ್ಜೆ", "ta" to "காலடி", "bn" to "পদক্ষেপ", "ml" to "ചുവട്")
}

/** One Warli figure (two triangles, a round head, stick limbs) walking; 100 box, feet at 96. */
fun Ink.warli(c: Any, solid: Boolean, pose: Int) {
    val w = if (solid) 2.6 else 1.6
    dot(50.0, 14.0, 7.0, if (solid) c else ca("#FFFFFF", 0.0)); if (!solid) ring(50.0, 14.0, 7.0, c, 1.2)
    val tri1 = "M 36 24 L 64 24 L 50 46 Z"; val tri2 = "M 50 46 L 38 66 L 62 66 Z"
    if (solid) { fill(tri1, c); fill(tri2, c) } else { line(tri1, c, 1.2); line(tri2, c, 1.2) }
    val sw = if (pose % 2 == 0) 1.0 else -1.0
    line("M 38 26 L ${30 - 6 * sw} 42 L ${26 - 4 * sw} 54", c, w)
    line("M 62 26 L ${70 + 6 * sw} 40 L ${76 + 2 * sw} 52", c, w)
    line("M 44 66 L ${40 - 8 * sw} 82 L ${36 - 10 * sw} 96", c, w)
    line("M 56 66 L ${60 + 8 * sw} 82 L ${66 + 6 * sw} 96", c, w)
}

/** Warli tarpa dance circle for a reached goal: figures around a musician. */
fun Ink.tarpaCircle(cx: Double, cy: Double, r: Double, n: Int, c: String) {
    for (i in 0 until n) {
        val a = i.toDouble() / n * PI * 2
        push(cx + cos(a) * r, cy + sin(a) * r * 0.45, r / 150); push(-50.0, -55.0); warli(c, true, i); pop(); pop()
    }
    push(cx, cy, r / 120); push(-50.0, -55.0); warli("#F2C14E", true, 0); pop(); pop()
    line("M ${cx + r * 0.08} ${cy - r * 0.18} L ${cx + r * 0.32} ${cy - r * 0.42}", "#F2C14E", 2.0)
}

fun Ink.stepsWidget(w: Double, h: Double, steps: Int, goal: Int, wariKm: Double, lang: String, permissionMissing: Boolean) {
    val mud = "#8A4B2E"; val chalk = "#F6EBD3"
    paperBg(w, h, mud, "#2A1206", 5)
    // Warli border: rows of little triangles top and bottom
    var x = 14.0
    while (x < w - 14) { fill("M $x 8 L ${x + 6} 8 L ${x + 3} 13 Z", ca(chalk, 0.8)); fill("M $x ${h - 8} L ${x + 6} ${h - 8} L ${x + 3} ${h - 13} Z", ca(chalk, 0.8)); x += 9 }
    val reached = steps >= goal
    val km = steps * 0.75 / 1000
    val wide = w / h >= 1.45
    val pad = 16.0
    if (permissionMissing) {
        text("Tap to allow step counting", pad, h / 2 - 10, w - 2 * pad, 20.0, fonts.sansBold, 11.0, chalk, Ink.Align.CENTER)
        return
    }
    if (wide) {
        text(lang(lang, Wari.TITLE), pad, 18.0, 120.0, 24.0, fonts.indic, 15.0, "#F2C14E")
        text(fmtInt(steps), pad, 34.0, w * 0.5, 50.0, fonts.serif, 38.0, chalk)
        text("of ${fmtInt(goal)} steps · about ${"%.1f".format(km)} km", pad, 82.0, w * 0.5, 14.0, fonts.sansBold, 8.5, "#F2C14E")
        // right: procession or dance
        val rx = w * 0.5; val rw = w - rx - pad
        if (reached) tarpaCircle(rx + rw / 2, 56.0, min(rw * 0.4, 44.0), 10, chalk)
        else {
            val n = 8; val filled = (steps.toDouble() / goal * n).toInt().coerceIn(0, n)
            val fw = rw / n; val sc = min(0.56, fw * 2.1 / 100)
            for (i in 0 until n) { push(rx + i * fw + fw / 2 - 50 * sc, 92 - 96 * sc + (if (i % 2 == 0) 0.0 else 3.0), sc); warli(chalk, i < filled, i); pop() }
            line("M $rx 96 L ${rx + rw} 96", ca(chalk, 0.5), 1.0)
        }
        // Wari strip
        val sy = h - 34.0
        val frac = (wariKm % Wari.TOTAL_KM) / Wari.TOTAL_KM
        val idx = (frac * (Wari.HALTS.size - 1)).toInt().coerceIn(0, Wari.HALTS.size - 2)
        val laps = (wariKm / Wari.TOTAL_KM).toInt()
        val lbl = (if (laps > 0) "Wari ${laps + 1} · " else "Wari · ") + "${wariKm.roundToInt() % Wari.TOTAL_KM.toInt()} of ~${Wari.TOTAL_KM.toInt()} km · past ${Wari.HALTS[idx]}, next ${Wari.HALTS[idx + 1]}"
        text(lbl, pad, sy - 22, w - 2 * pad, 12.0, fonts.sansBold, 7.5, ca(chalk, 0.85))
        val sx0 = pad; val sw = w - 2 * pad
        line("M $sx0 $sy L ${sx0 + sw} $sy", ca(chalk, 0.4), 1.0)
        for (i in Wari.HALTS.indices) { val hx = sx0 + sw * i / (Wari.HALTS.size - 1); dot(hx, sy, if (i == 0 || i == Wari.HALTS.size - 1) 2.6 else 1.6, ca(chalk, 0.8)) }
        line("M $sx0 $sy L ${sx0 + sw * frac} $sy", "#F2C14E", 2.2)
        val fx = sx0 + sw * frac
        line("M $fx ${sy + 1} L $fx ${sy - 10}", chalk, 1.2)
        fill("M $fx ${sy - 10} L ${fx + 8} ${sy - 7.5} L $fx ${sy - 5} Z", "#F08A24")
    } else {
        text(lang(lang, Wari.TITLE), pad, 16.0, w - 2 * pad, 20.0, fonts.indic, 12.0, "#F2C14E")
        text(fmtInt(steps), pad, 32.0, w - 2 * pad, 40.0, fonts.serif, 30.0, chalk)
        text("of ${fmtInt(goal)} · ${"%.1f".format(km)} km", pad, 70.0, w - 2 * pad, 12.0, fonts.sansBold, 8.0, "#F2C14E")
        if (reached) tarpaCircle(w / 2, h - 40, min(w * 0.3, 30.0), 8, chalk)
        else {
            val n = 5; val filled = (steps.toDouble() / goal * n).toInt().coerceIn(0, n); val fw = (w - 2 * pad) / n
            for (i in 0 until n) { push(pad + i * fw, h - 64, fw * 1.1 / 100); warli(chalk, i < filled, i); pop() }
        }
    }
}

// =====================================================================
// TWO-WINDOW CLOCK
// =====================================================================
class WindowSpec(val city: String, val lat: Double, val lon: Double, val zone: String, val subtitle: String)

/** One jharokha window showing the real sky over a place right now. */
fun Ink.skyWindow(x: Double, y: Double, w: Double, h: Double, ws: WindowSpec, utc: Long, seed: Int) {
    val sun = Sky.sun(ws.lat, ws.lon, utc)
    val (top, low) = Sky.palette(sun.altitude)
    shape(archPath(x - 4, y - 4, w + 8, h + 8), "#F2B544", Art.INK, 1.4)
    // sky: clip by drawing bands inside the arch, then re-stroke
    shape(archPath(x, y, w, h), top, Art.INK, 1.2)
    fill("M $x ${y + h * 0.55} L ${x + w} ${y + h * 0.55} L ${x + w} ${y + h} L $x ${y + h} Z", low)
    val night = sun.altitude < -6
    val R = Ink.Rng(seed)
    if (night) for (i in 0 until 12) { val sx = x + w * (0.1 + R.next() * 0.8); val sy = y + h * (0.22 + R.next() * 0.35); sparkle(sx, sy, 1.0 + R.next() * 1.8, "#F5E6A8") }
    // sun or moon along the window's arc, by hour angle and altitude
    fun place(p: Sky.Pos): Pair<Double, Double>? {
        if (p.altitude < -2) return null
        val px = x + w * (0.5 + p.hourAngle / 200.0).coerceIn(0.12, 0.88)
        val py = y + h * (0.62 - (p.altitude / 70.0).coerceIn(0.0, 1.0) * 0.36)
        return px to py
    }
    val orb = min(w, h) * 0.07
    place(sun)?.let { (sx, sy) -> dot(sx, sy, orb * 1.8, ca("#FFF4D0", 0.3)); shape(ellD(sx, sy, orb, orb), if (sun.altitude < 6) "#F06D4F" else "#F6C542", Art.INK, 1.0) }
    if (sun.altitude < 3) place(Sky.moon(ws.lat, ws.lon, utc))?.let { (mx, my) -> crescent(mx, my, orb * 0.9, top) }
    // hills, a hut, a tree
    val gy = y + h * 0.8
    fill("M $x $gy Q ${x + w * 0.3} ${gy - h * 0.1} ${x + w * 0.6} ${gy - h * 0.02} Q ${x + w * 0.8} ${gy - h * 0.08} ${x + w} ${gy - h * 0.03} L ${x + w} ${y + h} L $x ${y + h} Z", if (night) "#1E2440" else "#4C7A34")
    val hx = x + w * 0.62; val hs = w * 0.22
    shape("M $hx ${gy + 2} L $hx ${gy - hs * 0.45} L ${hx + hs} ${gy - hs * 0.45} L ${hx + hs} ${gy + 2} Z", if (night) "#3A2E4A" else "#C88A4A", Art.INK, 0.9)
    shape("M ${hx - hs * 0.12} ${gy - hs * 0.42} L ${hx + hs / 2} ${gy - hs * 0.95} L ${hx + hs * 1.12} ${gy - hs * 0.42} Z", if (night) "#4A3A5A" else "#B5532E", Art.INK, 0.9)
    fill("M ${hx + hs * 0.38} ${gy + 2} L ${hx + hs * 0.38} ${gy - hs * 0.25} L ${hx + hs * 0.62} ${gy - hs * 0.25} L ${hx + hs * 0.62} ${gy + 2} Z", if (night) "#F6C542" else "#3A2418")
    val tx = x + w * 0.26
    line("M $tx $gy L $tx ${gy - h * 0.16}", "#5A3A1E", 2.0)
    for (k in 0 until 5) { val a = k / 5.0 * PI * 2; shape(ellD(tx + cos(a) * w * 0.07, gy - h * 0.19 + sin(a) * w * 0.05, w * 0.06, w * 0.045), if (night) "#22304A" else "#3E8E3A", Art.INK, 0.6) }
    line(archPath(x, y, w, h), Art.INK, 1.2)
}

/** Background art for the two-window clock. Times themselves are live text views laid over the lower band. */
fun Ink.twoWindowWidget(w: Double, h: Double, here: WindowSpec, home: WindowSpec, utc: Long, diffLabel: String) {
    paperBg(w, h, "#6E1E22", "#000000", 9)
    dotFrame(w, h, "#F2B544", "#F2B544")
    // the lower 58 units are kept clear: live clocks (text views) sit there, then a caption line
    val gap = 12.0; val ww = (w - 36 - gap) / 2; val top = 22.0; val wh = max(30.0, h - top - 62)
    skyWindow(18.0, top, ww, wh, here, utc, 3)
    skyWindow(18 + ww + gap, top, ww, wh, home, utc, 8)
    for ((i, ws) in listOf(here, home).withIndex()) {
        val cx = 18 + i * (ww + gap)
        text("${ws.city.uppercase()} · ${ws.subtitle}", cx, h - 24, ww, 12.0, fonts.sansBold, 6.8, ca("#FBEBC8", 0.8), Ink.Align.CENTER)
    }
    // the time difference as a small medallion between the windows
    val mx = w / 2; val my = top + wh * 0.5
    shape(ellD(mx, my, 14.0, 14.0), "#F2B544", Art.INK, 1.2)
    text(diffLabel, mx - 14, my - 5, 28.0, 12.0, fonts.sansBold, 7.0, "#6E1E22", Ink.Align.CENTER)
}

// =====================================================================
// PROVERB OF THE DAY: a palm-leaf manuscript on red cloth
// =====================================================================
fun Ink.proverbWidget(w: Double, h: Double, p: Proverb) {
    paperBg(w, h, "#7A1F22", "#000000", 21)
    for (y in incl(10.0, h - 10, 6.0)) line("M 8 $y L ${w - 8} ${y + 1}", ca("#000000", 0.06), 0.6)
    val lx = 12.0; val ly = 14.0; val lw = w - 24; val lh = h - 28
    // the leaf: long rounded strip with slightly ragged dark edges and fibre lines
    val leaf = "M ${lx + 14} $ly L ${lx + lw - 14} ${ly + 1} Q ${lx + lw} ${ly + 2} ${lx + lw} ${ly + lh / 2} Q ${lx + lw} ${ly + lh - 1} ${lx + lw - 14} ${ly + lh} L ${lx + 14} ${ly + lh - 1} Q $lx ${ly + lh - 2} $lx ${ly + lh / 2} Q $lx ${ly + 1} ${lx + 14} $ly Z"
    fill(leaf, "#D8B57A")
    val R = Ink.Rng(5)
    for (i in 0 until 26) { val yy = ly + 3 + R.next() * (lh - 6); line("M ${lx + 6} $yy L ${lx + lw - 6} ${yy + R.next() * 1.2}", ca("#9A7444", 0.35), 0.5) }
    line(leaf, "#7A5530", 1.6)
    // binding holes at each end, with a short red thread
    for (hx in listOf(lx + 9, lx + lw - 9)) {
        line("M $hx ${ly + lh / 2} Q ${hx + (if (hx < w / 2) -6 else 6)} ${ly + lh / 2 + 18} $hx ${ly + lh + 10}", "#C2185B", 1.6)
        shape(ellD(hx, ly + lh / 2, 3.0, 3.0), "#4A2A14", "#7A5530", 0.8)
    }
    val ink = "#3A2412"
    val wide = w / h >= 1.45
    val ms = min(lh * 0.6, lw * 0.2)
    if (wide) {
        push(lx + lw - ms - 20, ly + (lh - ms) / 2, ms / 100); proverbMotif(p.motif, ink); pop()
        val tx = lx + 20; val tw = lw - ms - 46
        var y = ly + 7
        y += text((Proverbs.LANG_NAMES[p.lang] ?: "").uppercase() + " · PROVERB OF THE DAY", tx, y, tw, 10.0, fonts.sansBold, 6.5, "#7A5530") + 2
        val n = p.text.length
        val fs = when { n > 36 -> 11.0; n > 24 -> 13.0; else -> 16.0 }
        y += text(p.text, tx, y, tw, fs * 2.6, fonts.indic, fs, ink) + 1
        y += text(p.roman, tx, y, tw, 22.0, fonts.italic, 8.5, "#5A3A1E") + 3
        text("“" + p.literal + "”", tx, y, tw, ly + lh - 24 - y, fonts.italic, 7.8, "#5A3A1E")
        text(p.sense, tx, ly + lh - 20, tw, 18.0, fonts.sansBold, 7.6, ink)
    } else {
        push(lx + lw - ms * 0.75 - 14, ly + 8, ms * 0.75 / 100); proverbMotif(p.motif, ink); pop()
        val tx = lx + 16; val tw = lw - 32
        var y = ly + 10
        y += text(p.text, tx, y, tw - ms * 0.9, lh * 0.5, fonts.indic, if (p.text.length > 24) 9.5 else 12.0, ink) + 4
        text(p.sense, tx, y, tw, ly + lh - 8 - y, fonts.sansBold, 7.2, "#5A3A1E")
    }
}

/** Etched line drawings for the leaf, single ink colour, 100 box. */
fun Ink.proverbMotif(k: String, c: String) {
    val lw = 2.2
    fun ln(d: String, w: Double = lw) = line(d, c, w)
    when (k) {
        "pot" -> { ln("M 34 26 L 66 26 L 62 34 Q 88 44 84 66 Q 78 90 50 90 Q 22 90 16 66 Q 12 44 38 34 Z"); ln("M 22 58 Q 50 66 78 58", 1.4); for (i in 0 until 6) dot(28.0 + i * 9, 70.0, 1.4, c); ln("M 66 20 Q 72 10 68 4", 1.4) }
        "drops" -> { for ((x, y, s) in listOf(Triple(30.0, 20.0, 1.0), Triple(58.0, 14.0, 0.8), Triple(46.0, 40.0, 1.2), Triple(70.0, 44.0, 0.9))) ln("M $x ${y - 10 * s} Q ${x + 7 * s} ${y + 2 * s} $x ${y + 6 * s} Q ${x - 7 * s} ${y + 2 * s} $x ${y - 10 * s} Z", 1.6)
            ln("M 24 70 L 76 70 L 70 92 L 30 92 Z"); ln("M 30 78 Q 50 74 70 78", 1.2) }
        "bird" -> { ln("M 20 56 Q 40 40 62 48 Q 72 40 80 44 Q 74 50 72 56 Q 60 70 30 66 Z"); ln("M 40 50 Q 48 34 62 30", 1.4); dot(74.0, 46.0, 1.4, c); ln("M 80 44 L 88 46", 1.6)
            for (x in listOf(22.0, 34.0, 46.0, 58.0, 70.0)) { ln("M $x 92 L $x 76", 1.2); dot(x, 74.0, 2.0, c) } }
        "drum" -> { ln("M 18 36 Q 50 28 82 36 L 82 70 Q 50 78 18 70 Z"); ln("M 18 36 Q 50 44 82 36", 1.4); for (x in listOf(30.0, 42.0, 54.0, 66.0)) ln("M $x 40 L ${x + 6} 72", 1.0)
            ln("M 26 22 L 40 34", 1.6); ln("M 74 22 L 60 34", 1.6) }
        "bells" -> { ln("M 10 40 Q 50 52 90 40", 1.6); for (i in 0 until 7) { val x = 16.0 + i * 11; val y = 44 + sin(i / 6.0 * PI) * 5; ln("M ${x - 4} ${y + 4} Q $x ${y - 2} ${x + 4} ${y + 4} Q ${x + 4} ${y + 12} $x ${y + 12} Q ${x - 4} ${y + 12} ${x - 4} ${y + 4} Z", 1.2); dot(x, y + 10, 1.1, c) }
            ln("M 30 80 Q 50 70 70 82", 1.0); ln("M 30 86 Q 52 78 72 90", 1.0) }
        "ginger" -> { ln("M 16 60 Q 20 44 36 48 Q 40 32 54 38 Q 64 28 74 40 Q 88 44 84 58 Q 86 72 70 70 Q 60 82 46 72 Q 30 80 24 70 Q 12 70 16 60 Z"); ln("M 40 56 L 48 52 M 60 54 L 66 50", 1.2) }
        "mango" -> { ln("M 50 20 Q 80 24 78 56 Q 76 86 48 88 Q 22 86 26 58 Q 28 34 50 20 Z"); ln("M 50 20 Q 54 10 62 8", 1.6); ln("M 56 12 Q 74 4 82 16 Q 70 20 56 12 Z", 1.4); ln("M 38 46 Q 36 60 44 70", 1.0) }
        "sprout" -> { ln("M 14 86 Q 50 78 86 86", 1.6); ln("M 50 84 Q 48 60 50 40"); ln("M 50 54 Q 30 52 24 36 Q 42 34 50 50 Z", 1.6); ln("M 50 44 Q 66 40 76 24 Q 58 22 50 40 Z", 1.6); for (x in listOf(24.0, 36.0, 64.0, 76.0)) dot(x, 90.0, 1.4, c) }
        "ripples" -> { for (r in listOf(10.0, 20.0, 32.0)) ln(ellD(50.0, 70.0, r * 1.3, r * 0.4), 1.4); ln("M 46 12 Q 50 40 48 58 Q 46 66 38 66 Q 30 66 32 60", 2.0) }
        "sand" -> { ln("M 20 70 Q 22 56 36 56 L 62 54 Q 70 54 70 60 Q 70 64 62 64 L 54 64 Q 76 64 80 70 Q 80 80 64 82 L 30 82 Q 20 80 20 70 Z"); ln("M 34 54 Q 46 42 58 54", 1.4); for (i in 0 until 7) dot(38.0 + i * 3, 48.0 - (i % 2) * 2, 1.1, c)
            ln(ellD(76.0, 26.0, 16.0, 16.0), 1.4); ln("M 60 26 L 92 26 M 76 10 Q 66 26 76 42 M 76 10 Q 86 26 76 42", 1.0) }
        "elephant" -> { ln("M 22 56 Q 22 34 46 32 Q 66 30 72 42 Q 84 44 84 58 Q 86 74 80 84 L 74 84 L 74 70 M 22 56 L 22 84 L 30 84 L 30 70 L 44 70 L 44 84 L 52 84 L 52 70 L 64 70 L 66 84 L 74 84")
            ln("M 84 58 Q 92 70 88 82", 2.0); ln("M 62 40 Q 54 50 62 60 Q 70 56 70 46", 1.4); dot(76.0, 48.0, 1.4, c); ln("M 22 50 Q 14 54 16 62", 1.4); for (x in listOf(32.0, 42.0, 52.0)) dot(x, 46.0, 1.3, c) }
        "ants" -> { ln("M 10 82 Q 30 60 50 66 Q 70 72 90 54 L 90 92 L 10 92 Z", 1.6); for (i in 0 until 6) { val x = 16.0 + i * 13; val y = 70 - sin(i / 5.0 * PI) * 10 - i * 1.2; dot(x, y, 1.8, c); dot(x + 3.2, y - 0.6, 1.4, c); dot(x + 5.8, y - 1.2, 1.6, c); ln("M $x ${y - 2} L ${x + 1} ${y - 5}", 0.8) } }
        "ammi" -> { ln("M 12 64 L 88 64 L 84 82 L 16 82 Z"); for (x in listOf(24.0, 40.0, 56.0, 72.0)) ln("M $x 68 L ${x + 6} 78", 1.0); ln("M 30 58 Q 30 48 50 46 Q 70 48 70 58 Q 50 62 30 58 Z") }
        "meal" -> { ln("M 6 64 Q 50 40 94 64 Q 50 88 6 64 Z"); ln("M 10 64 Q 50 56 90 64", 1.2); ln(ellD(42.0, 60.0, 12.0, 6.0), 1.6); for (p in listOf(64.0 to 58.0, 72.0 to 64.0, 30.0 to 68.0)) ln(ellD(p.first, p.second, 5.0, 3.0), 1.2) }
        "sheaf" -> { for (dx in listOf(-14.0, -6.0, 2.0, 10.0, 18.0)) { ln("M ${50 + dx * 0.4} 90 Q ${50 + dx * 0.6} 60 ${50 + dx} 30", 1.4); for (k in 0 until 4) { val y = 30.0 + k * 7; dot(50 + dx + (if (k % 2 == 0) 2.5 else -2.5), y, 2.0, c) } }
            ln("M 40 66 Q 50 70 60 66", 2.2) }
        "plant" -> { ln("M 30 90 L 32 64 L 68 64 L 70 90 Z"); ln("M 26 64 L 74 64 L 72 58 L 28 58 Z", 1.6); ln("M 50 58 L 50 20", 1.8)
            for (y in listOf(24.0, 34.0, 44.0)) { ln(ellD(42.0, y, 7.0, 3.0), 1.2); ln(ellD(58.0, y + 4, 7.0, 3.0), 1.2) } }
        "cloud" -> { ln("M 22 52 Q 14 52 14 42 Q 14 30 28 32 Q 32 16 50 18 Q 66 16 70 30 Q 86 28 86 42 Q 86 54 74 52 Z"); ln("M 50 54 L 42 70 L 52 70 L 44 90", 2.0); for (x in listOf(26.0, 66.0, 78.0)) ln("M $x 60 L ${x - 3} 68", 1.2) }
        "lamp" -> { ln("M 10 62 Q 50 96 90 58 Q 90 52 82 52 Q 68 60 50 60 Q 28 60 10 62 Z"); ln("M 84 50 Q 76 36 84 18 Q 94 36 84 50 Z", 1.6); dot(84.0, 42.0, 1.6, c) }
        "flake" -> { for (i in 0 until 3) { val a = i * PI / 3; ln("M ${50 - cos(a) * 34} ${50 - sin(a) * 34} L ${50 + cos(a) * 34} ${50 + sin(a) * 34}", 1.6) }
            for (i in 0 until 6) { val a = i * PI / 3; val ex = 50 + cos(a) * 22; val ey = 50 + sin(a) * 22
                ln("M ${ex + cos(a + 0.8) * 8} ${ey + sin(a + 0.8) * 8} L $ex $ey L ${ex + cos(a - 0.8) * 8} ${ey + sin(a - 0.8) * 8}", 1.2) } }
        "jasmine" -> { ln("M 10 90 Q 30 60 50 56 Q 74 50 86 20", 1.6); for (p in listOf(30.0 to 66.0, 50.0 to 54.0, 70.0 to 42.0, 82.0 to 26.0, 40.0 to 40.0)) { for (a in 0 until 5) { val an = a / 5.0 * PI * 2; ln(ellD(p.first + cos(an) * 4.5, p.second + sin(an) * 4.5, 3.0, 3.0), 1.0) }; dot(p.first, p.second, 1.4, c) } }
        "squirrel" -> { ln("M 30 76 Q 22 60 34 50 Q 46 44 54 54 Q 60 44 70 46 Q 78 48 76 56 Q 74 62 66 62 Q 66 76 56 80 Z"); ln("M 30 76 Q 10 70 12 46 Q 14 30 30 32 Q 22 44 34 50", 1.8); dot(70.0, 52.0, 1.4, c); ln("M 70 46 L 72 40", 1.4)
            for (i in 0 until 3) ln("M ${40 + i * 6} 56 Q ${42 + i * 6} 64 ${40 + i * 6} 72", 1.0); ln("M 8 90 L 92 90", 1.4); for (x in listOf(20.0, 40.0, 60.0, 80.0)) ln(ellD(x, 86.0, 7.0, 4.0), 1.0) }
        "crow" -> { ln("M 18 52 Q 34 34 58 40 Q 68 30 78 34 Q 72 40 72 46 Q 64 62 40 62 Q 28 64 18 52 Z"); dot(70.0, 38.0, 1.4, c); ln("M 78 34 L 88 36 L 78 40", 1.4); ln("M 40 62 L 38 74 M 50 62 L 52 74", 1.4)
            ln(ellD(40.0, 84.0, 14.0, 6.0), 1.6); ln("M 34 80 Q 40 74 46 80", 1.2); dot(38.0, 78.0, 1.0, c) }
        else -> ln(ellD(50.0, 50.0, 30.0, 30.0))
    }
}
