package com.rangmausam

import kotlin.math.PI
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

/**
 * Low-precision sun and moon positions (good to a degree or so, plenty for painting a sky).
 * Sun: standard almanac approximation. Moon: phase from the mean synodic month; its place in the sky
 * is approximated as trailing the sun by phase x 360 degrees (enough to put a crescent near sunset).
 */
object Sky {
    private const val D2R = PI / 180
    private const val R2D = 180 / PI

    class Pos(val altitude: Double, val hourAngle: Double)

    private fun days(utcMillis: Long) = utcMillis / 86400000.0 + 2440587.5 - 2451545.0

    fun sun(lat: Double, lon: Double, utcMillis: Long): Pos {
        val d = days(utcMillis)
        val g = (357.529 + 0.98560028 * d) * D2R
        val q = 280.459 + 0.98564736 * d
        val l = (q + 1.915 * sin(g) + 0.020 * sin(2 * g)) * D2R
        val e = (23.439 - 0.00000036 * d) * D2R
        val ra = atan2(cos(e) * sin(l), cos(l)) * R2D
        val dec = asin(sin(e) * sin(l))
        val gmst = 18.697374558 + 24.06570982441908 * d
        var h = (gmst * 15 + lon - ra) % 360.0
        if (h > 180) h -= 360; if (h < -180) h += 360
        val alt = asin(sin(lat * D2R) * sin(dec) + cos(lat * D2R) * cos(dec) * cos(h * D2R)) * R2D
        return Pos(alt, h)
    }

    /** 0 = new moon, 0.5 = full. */
    fun moonPhase(utcMillis: Long): Double {
        val jd = utcMillis / 86400000.0 + 2440587.5
        val p = (jd - 2451550.1) / 29.530588853
        return p - floor(p)
    }

    fun moon(lat: Double, lon: Double, utcMillis: Long): Pos {
        val s = sun(lat, lon, utcMillis)
        var h = s.hourAngle - moonPhase(utcMillis) * 360
        while (h < -180) h += 360; while (h > 180) h -= 360
        val alt = asin(cos(lat * D2R) * cos(h * D2R)) * R2D
        return Pos(alt, h)
    }

    /** Next time (UTC millis) after [from] that the sun crosses -0.83 deg in the given direction; null in polar day or night. */
    fun nextCrossing(lat: Double, lon: Double, from: Long, rising: Boolean): Long? {
        var t = from; var prev = sun(lat, lon, t).altitude
        val step = 5 * 60_000L
        for (i in 0 until 12 * 26) {
            t += step
            val a = sun(lat, lon, t).altitude
            if (rising && prev < -0.83 && a >= -0.83) return t
            if (!rising && prev > -0.83 && a <= -0.83) return t
            prev = a
        }
        return null
    }

    /** Sky colours (upper, lower) for a sun altitude, in the folk palette. */
    fun palette(alt: Double): Pair<String, String> = when {
        alt < -12 -> "#121A3E" to "#1E2A5C"
        alt < -6 -> "#1E2A5C" to "#4A3C78"
        alt < -0.8 -> "#3B3F7A" to "#C8607A"
        alt < 6 -> "#E07A4A" to "#F6C76A"
        alt < 20 -> "#7FB3D5" to "#F6D99A"
        else -> "#5FA8D3" to "#BFE3F0"
    }
}
