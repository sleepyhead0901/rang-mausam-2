package com.rangmausam

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Settings screen: place, script, units, and a gallery of every weather state. */
class MainActivity : Activity() {
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var cityBox: EditText
    private lateinit var homeStatus: TextView
    private lateinit var stepStatus: TextView
    private val paper = Color.parseColor("#F6EBD3")
    private val ink = Color.parseColor("#2A1A14")
    private val sindoor = Color.parseColor("#B8291A")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(28), dp(20), dp(40)); setBackgroundColor(paper) }
        val scroll = ScrollView(this).apply { setBackgroundColor(paper); addView(root) }
        setContentView(scroll)

        root.addView(TextView(this).apply { text = "Rang Mausam"; textSize = 30f; setTextColor(ink); typeface = Store.fonts(this@MainActivity).serif })
        root.addView(label("Five folk-art widgets: weather, raga of the hour, steps, two windows, and a proverb a day. Long-press your home screen, choose Widgets, and look for Rang Mausam."))

        preview = ImageView(this).apply { adjustViewBounds = true; setPadding(0, dp(16), 0, dp(8)) }
        root.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        status = label("")
        root.addView(status)

        root.addView(heading("Place"))
        root.addView(button("Use my location") { askLocation() })
        val cityRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        cityBox = EditText(this).apply { hint = "Or type a city, e.g. Chamarajanagar"; setSingleLine(true); setTextColor(ink) }
        cityRow.addView(cityBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        cityRow.addView(button("Set") { setCity(cityBox.text.toString().trim()) })
        root.addView(cityRow)

        root.addView(heading("Script for the weather word"))
        val langs = listOf("hi" to "हिंदी", "kn" to "ಕನ್ನಡ", "ta" to "தமிழ்", "bn" to "বাংলা", "ml" to "മലയാളം")
        root.addView(row(langs.map { (code, name) -> name to { Store.setLang(this, code); changed() } }))

        root.addView(heading("Units"))
        root.addView(row(listOf("°C" to { Store.setFahrenheit(this, false); changed() }, "°F" to { Store.setFahrenheit(this, true); changed() })))

        root.addView(heading("Two-window clock: your home window"))
        root.addView(label("The left window follows where you are. Choose the place for the right one."))
        homeStatus = label("Home window: ${More.homeCity(this)}")
        root.addView(homeStatus)
        val homeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val homeBox = EditText(this).apply { hint = "e.g. Port Blair"; setSingleLine(true); setTextColor(ink) }
        homeRow.addView(homeBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        homeRow.addView(button("Set") { setHome(homeBox.text.toString().trim()) })
        root.addView(homeRow)

        root.addView(heading("Steps"))
        root.addView(label("Counts with your phone's step sensor. Every step also moves you along the Pandharpur Wari route."))
        root.addView(button("Allow step counting") { askSteps() })
        stepStatus = label("Daily goal: ${More.goal(this)} steps")
        root.addView(stepStatus)
        root.addView(row(listOf(4000, 6000, 8000, 10000).map { g -> "%,d".format(g) to { More.setGoal(this, g); stepStatus.text = "Daily goal: %,d steps".format(g); W.refreshAll(this) } }))

        root.addView(heading("Proverb of the day: languages"))
        val langRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((code, name) in Proverbs.LANG_NAMES) {
            val b = Button(this).apply { isAllCaps = false; textSize = 11f }
            fun paint() { b.text = (if (code in More.proverbLangs(this@MainActivity)) "✓ " else "") + name }
            paint()
            b.setOnClickListener {
                val cur = More.proverbLangs(this).toMutableSet()
                if (code in cur && cur.size > 1) cur.remove(code) else cur.add(code)
                More.setProverbLangs(this, cur); paint(); W.refreshAll(this)
            }
            langRow.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(langRow)
        root.addView(label("Tap the widget for the next proverb."))

        root.addView(button("Refresh all widgets now") { changed() })

        root.addView(heading("Raga of the hour, and today's proverb"))
        val nowPreview = ImageView(this).apply { adjustViewBounds = true; setPadding(0, dp(8), 0, 0) }
        val provPreview = ImageView(this).apply { adjustViewBounds = true; setPadding(0, dp(10), 0, 0) }
        root.addView(nowPreview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(provPreview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val now = java.time.LocalTime.now(); val rg = Ragas.at(now.hour)
        val sc = resources.displayMetrics.widthPixels / 380f
        nowPreview.setImageBitmap(Art.canvas(338.0, 158.0, Store.fonts(this), sc) { ragaWidget(338.0, 158.0, rg, (((now.hour - rg.start + 24) % 24) * 60 + now.minute) / 120.0, "") })
        provPreview.setImageBitmap(Art.canvas(338.0, 158.0, Store.fonts(this), sc) { proverbWidget(338.0, 158.0, ProverbWidget.today(this@MainActivity)) })

        root.addView(heading("Every weather state"))
        root.addView(label("What the widget shows for each kind of weather. Rain, snow and storms count if they are expected in the next 12 hours."))
        val fonts = Store.fonts(this)
        val scale = resources.displayMetrics.widthPixels / 380f
        for (k in Art.KEYS) {
            val iv = ImageView(this).apply { adjustViewBounds = true; setPadding(0, dp(10), 0, 0); contentDescription = Art.LABELS[k] }
            iv.setImageBitmap(Art.render("medium", Weather.demo(k), Store.lang(this), fonts, scale))
            root.addView(iv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        root.addView(label("Forecast data: Open-Meteo.com (CC BY 4.0). Fonts: Playfair Display and Lora (SIL Open Font License)."))

        if (Store.forecast(this) == null && !Store.hasLocationPermission(this)) askLocation() else loadPreview(network = Store.forecast(this) == null)
    }

    private fun heading(t: String) = TextView(this).apply { text = t; textSize = 17f; setTextColor(sindoor); setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(22), 0, dp(6)) }
    private fun label(t: String) = TextView(this).apply { text = t; textSize = 14f; setTextColor(ink); setPadding(0, dp(4), 0, dp(4)) }
    private fun button(t: String, onClick: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { onClick() } }
    private fun row(items: List<Pair<String, () -> Unit>>) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        for ((t, f) in items) addView(button(t, f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    }

    private fun changed() { loadPreview(network = true); W.refreshAll(this) }

    private fun setHome(name: String) {
        if (name.isEmpty()) return
        homeStatus.text = "Looking up $name…"
        Thread {
            val g = try { Weather.geocode(name) } catch (e: Exception) { null }
            runOnUiThread {
                if (g == null) homeStatus.text = "Could not find \"$name\"."
                else { More.setHome(this, g); homeStatus.text = "Home window: ${g.name} (${g.zone})"; W.refreshAll(this) }
            }
        }.start()
    }

    private fun askSteps() {
        if (StepsWidget.permitted(this)) { stepStatus.text = "Step counting is on. Goal: %,d steps".format(More.goal(this)); W.refreshAll(this); return }
        requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), 8)
    }

    private fun loadPreview(network: Boolean) {
        status.text = if (network) "Fetching the forecast…" else ""
        Thread {
            val m = RangWidget.currentModel(this, network)
            val bmp = Art.render("medium", m, Store.lang(this), Store.fonts(this), resources.displayMetrics.widthPixels / 380f)
            runOnUiThread {
                preview.setImageBitmap(bmp)
                status.text = "Showing ${m.place}. Tap Refresh after changing settings."
            }
        }.start()
    }

    private fun setCity(name: String) {
        if (name.isEmpty()) return
        status.text = "Looking up $name…"
        Thread {
            val r = try { Weather.geocode(name) } catch (e: Exception) { null }
            runOnUiThread {
                if (r == null) status.text = "Could not find \"$name\". Try a nearby town or check your connection."
                else { Store.saveLocation(this, r.lat, r.lon, r.name, "city"); changed() }
            }
        }.start()
    }

    private fun askLocation() {
        if (Store.hasLocationPermission(this)) { fetchFix(); return }
        requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 8) { askSteps(); return }
        if (requestCode == 7 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) fetchFix()
        else { status.text = "No location permission. Type a city instead."; loadPreview(network = true) }
    }

    /** Gets a fresh fix while the app is open, so the widget has a place even in the background. */
    private fun fetchFix() {
        status.text = "Finding you…"
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val save: (android.location.Location?) -> Unit = { loc ->
            val l = loc ?: Store.lastFix(this)
            if (l == null) runOnUiThread { status.text = "Could not get a location fix. Type a city instead." }
            else Thread {
                val name = Store.placeName(this, l.latitude, l.longitude) ?: "Your location"
                Store.saveLocation(this, l.latitude, l.longitude, name, "gps")
                runOnUiThread { changed() }
            }.start()
        }
        try {
            if (Build.VERSION.SDK_INT >= 30 && lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.getCurrentLocation(LocationManager.NETWORK_PROVIDER, null, mainExecutor) { save(it) }
            } else save(null)
        } catch (e: SecurityException) { save(null) }
    }

    override fun onResume() { super.onResume(); window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR }
}
