package com.rangmausam

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate
import java.time.LocalTime
import java.util.Locale

/** Forecast from Open-Meteo (free, no key) and the rules that turn it into a carry-list. */
object Weather {

    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "RangMausam/1.0 (Android widget)")
        try {
            if (c.responseCode != 200) throw IllegalStateException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    fun forecastUrl(lat: Double, lon: Double, fahrenheit: Boolean): String =
        "https://api.open-meteo.com/v1/forecast?latitude=" + String.format(Locale.US, "%.3f", lat) +
            "&longitude=" + String.format(Locale.US, "%.3f", lon) +
            "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,is_day" +
            "&hourly=weather_code,precipitation_probability" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min" +
            "&timezone=auto&forecast_days=7&wind_speed_unit=kmh" +
            (if (fahrenheit) "&temperature_unit=fahrenheit" else "")

    class Geo(val lat: Double, val lon: Double, val name: String, val zone: String)

    /** City name to coordinates and time zone, or null. */
    fun geocode(name: String): Geo? {
        val js = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&format=json&name=" + URLEncoder.encode(name, "UTF-8")))
        val arr = js.optJSONArray("results") ?: return null
        if (arr.length() == 0) return null
        val r = arr.getJSONObject(0)
        return Geo(r.getDouble("latitude"), r.getDouble("longitude"), r.optString("name", name), r.optString("timezone", "UTC"))
    }

    private fun isRain(c: Int) = (c in 51..67) || (c in 80..82)
    private fun isSnow(c: Int) = (c in 71..77) || c == 85 || c == 86
    private fun isStorm(c: Int) = c >= 95
    private fun isFog(c: Int) = c == 45 || c == 48

    private fun hourLabel(h: Int): String = "${if (h % 12 == 0) 12 else h % 12} ${if (h < 12) "am" else "pm"}"

    /** Rain, snow and storm look 12 hours ahead, so the umbrella shows up before the rain does. */
    fun classify(json: String, place: String, fahrenheit: Boolean, now: LocalTime = LocalTime.now()): Model {
        val j = JSONObject(json)
        val hot = if (fahrenheit) 95.0 else 35.0
        val cold = if (fahrenheit) 46.0 else 8.0
        val cur = j.getJSONObject("current")
        val code = cur.getInt("weather_code")
        val t = cur.getDouble("temperature_2m")
        val wind = cur.getDouble("wind_speed_10m")
        val day = cur.getInt("is_day") == 1
        val h = j.getJSONObject("hourly")
        val times = h.getJSONArray("time")
        val codes = h.getJSONArray("weather_code")
        val probs = h.optJSONArray("precipitation_probability")
        val curHour = cur.getString("time").substring(0, 13) + ":00"
        var i0 = 0
        for (k in 0 until times.length()) if (times.getString(k) == curHour) { i0 = k; break }

        fun ahead(test: (Int) -> Boolean, pMin: Int): Int {
            for (k in i0 until minOf(i0 + 12, times.length())) {
                val p = if (probs != null && !probs.isNull(k)) probs.getInt(k) else 0
                if (!codes.isNull(k) && test(codes.getInt(k)) && (p >= pMin || k == i0)) return k
            }
            return -1
        }

        var soon = -1
        val key: String
        if (isStorm(code)) key = "storm"
        else if (ahead(::isStorm, 40).also { soon = it } >= 0) key = "storm"
        else if (isSnow(code)) key = "snow"
        else if (ahead(::isSnow, 40).also { soon = it } >= 0) key = "snow"
        else if (isRain(code)) key = "rain"
        else if (ahead(::isRain, 50).also { soon = it } >= 0) key = "rain"
        else if (isFog(code)) key = "fog"
        else if (t >= hot && day) key = "hot"
        else if (wind >= 30) key = "windy"
        else if (t <= cold) key = "cold"
        else if (code <= 1) key = if (day) "sunny" else "night"
        else key = "cloudy"
        if (isStorm(code) || isSnow(code) || isRain(code)) soon = -1

        val advice = if (soon > i0) {
            val hr = times.getString(soon).substring(11, 13).toInt()
            Art.soon(key, hourLabel(hr)) ?: Art.ADVICE.getValue(key)
        } else Art.ADVICE.getValue(key)

        val d = j.getJSONObject("daily")
        val dTime = d.getJSONArray("time"); val dCode = d.getJSONArray("weather_code")
        val dMax = d.getJSONArray("temperature_2m_max"); val dMin = d.getJSONArray("temperature_2m_min")
        fun dkey(c: Int, mx: Double) = when {
            isStorm(c) -> "storm"; isSnow(c) -> "snow"; isRain(c) -> "rain"; isFog(c) -> "fog"
            mx >= hot -> "hot"; mx <= cold -> "cold"; c <= 1 -> "sunny"; else -> "cloudy"
        }
        val daily = ArrayList<Day>()
        for (k in 1 until minOf(6, dTime.length())) {
            val dow = LocalDate.parse(dTime.getString(k)).dayOfWeek.value % 7
            daily.add(Day(dow, dkey(dCode.getInt(k), dMax.getDouble(k)), dMax.getDouble(k), dMin.getDouble(k)))
        }
        val time = "${if (now.hour % 12 == 0) 12 else now.hour % 12}:${now.minute.toString().padStart(2, '0')} ${if (now.hour < 12) "am" else "pm"}"
        return Model(key, !day, t, cur.getDouble("apparent_temperature"), dMax.getDouble(0), dMin.getDouble(0), place, time, advice, daily)
    }

    fun demo(key: String, place: String = "Preview"): Model {
        val b = mapOf("sunny" to listOf(29.0, 31.0, 20.0), "hot" to listOf(41.0, 43.0, 29.0), "cloudy" to listOf(24.0, 26.0, 19.0), "rain" to listOf(23.0, 25.0, 21.0),
            "storm" to listOf(27.0, 30.0, 23.0), "snow" to listOf(-2.0, 1.0, -6.0), "fog" to listOf(9.0, 17.0, 7.0), "cold" to listOf(6.0, 11.0, 3.0),
            "windy" to listOf(26.0, 28.0, 22.0), "night" to listOf(19.0, 28.0, 17.0)).getValue(key)
        val seq = listOf("sunny", "rain", "cloudy", "storm", "hot", "fog", "cold", "snow", "windy")
        val base = if (key == "night") 0 else seq.indexOf(key)
        val today = LocalDate.now().dayOfWeek.value % 7
        return Model(key, key == "night", b[0], b[0] - 1, b[1], b[2], place, "sample", Art.ADVICE.getValue(key),
            (0 until 5).map { Day((today + it + 1) % 7, seq[(base + it + 1) % seq.size], b[1] + (it % 3) - 1, b[2]) })
    }
}
