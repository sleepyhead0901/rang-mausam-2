plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rangmausam"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rangmausam"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }

    // One fixed signing key, so each new build installs over the last one (GitHub otherwise makes a new key every build).
    signingConfigs {
        create("shared") {
            storeFile = file("rangmausam-debug.jks")
            storePassword = "rangmausam"
            keyAlias = "rangmausam"
            keyPassword = "rangmausam"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("shared")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
